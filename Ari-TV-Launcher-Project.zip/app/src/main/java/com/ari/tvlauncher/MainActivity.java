package com.ari.tvlauncher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        getWindow().setStatusBarColor(Color.rgb(12, 17, 31));
        getWindow().setNavigationBarColor(Color.rgb(12, 17, 31));
        buildHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (getWindow().getDecorView() != null) buildHome();
    }

    private void buildHome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(28), dp(20), dp(28), dp(18));
        root.setBackgroundColor(Color.rgb(12, 17, 31));

        TextView title = new TextView(this);
        title.setText("ARI  |  TV");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Tus aplicaciones, sin anuncios");
        subtitle.setTextColor(Color.rgb(169, 184, 210));
        subtitle.setTextSize(14);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(4);
        subParams.bottomMargin = dp(18);
        root.addView(subtitle, subParams);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(5);
        grid.setUseDefaultMargins(false);

        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        Collections.sort(apps, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });

        for (ResolveInfo info : apps) {
            if (info.activityInfo.packageName.equals(getPackageName())) continue;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setFocusable(true);
            card.setClickable(true);
            card.setPadding(dp(8), dp(12), dp(8), dp(10));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.rgb(28, 38, 59));
            bg.setCornerRadius(dp(14));
            card.setBackground(bg);

            TextView icon = new TextView(this);
            icon.setGravity(Gravity.CENTER);
            icon.setTextSize(34);
            try {
                icon.setCompoundDrawablesWithIntrinsicBounds(null, info.loadIcon(pm), null, null);
                icon.setText("");
            } catch (Exception ignored) {}
            card.addView(icon, new LinearLayout.LayoutParams(dp(58), dp(54)));

            TextView label = new TextView(this);
            label.setText(info.loadLabel(pm));
            label.setTextColor(Color.WHITE);
            label.setTextSize(13);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(2);
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(-1, dp(38));
            labelParams.topMargin = dp(8);
            card.addView(label, labelParams);

            card.setOnFocusChangeListener((v, focused) -> {
                GradientDrawable focusBg = new GradientDrawable();
                focusBg.setColor(focused ? Color.rgb(48, 78, 124) : Color.rgb(28, 38, 59));
                focusBg.setCornerRadius(dp(14));
                if (focused) focusBg.setStroke(dp(2), Color.rgb(133, 190, 255));
                v.setBackground(focusBg);
                v.setScaleX(focused ? 1.04f : 1f);
                v.setScaleY(focused ? 1.04f : 1f);
            });
            final String packageName = info.activityInfo.packageName;
            final String className = info.activityInfo.name;
            card.setOnClickListener(v -> {
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(packageName, className);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(launch); } catch (Exception ignored) {}
            });

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = dp(142);
            lp.height = dp(124);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            grid.addView(card, lp);
        }

        scroll.addView(grid);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        if (grid.getChildCount() > 0) grid.getChildAt(0).requestFocus();
    }
}
